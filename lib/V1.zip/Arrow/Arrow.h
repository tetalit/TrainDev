#ifndef __ARROW_H_
#define __ARROW_H_

#include "ArrowCmd.h"
#include "DeviceBase.h"

// Класс поезда
class Arrow : public DeviceBase<ArrowCmd>
{

public:
  // Конструктор с номером
  Arrow(unsigned char _number);
  // Конструктор с номером и командами
  Arrow(unsigned char _number, std::vector<ArrowCmd> _commands);
};

#endif //__ARROW_H_
