#include "Arrow.h"

// Конструктор
Arrow::Arrow(unsigned char _number) : DeviceBase(_number)
{
}

// Конструктор с указанными параметрами
Arrow::Arrow(unsigned char _number, std::vector<ArrowCmd> _commands)  : DeviceBase(_number, _commands)
{
}