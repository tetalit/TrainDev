#pragma once
#ifndef __TRAFFIC_CMD_H_
#define __TRAFFIC_CMD_H_

#include "Definitions.h"

struct TrafficCmd
{
public:
  // Массив светодиодов
  unsigned char trafficLeds[4];
  // Конструктор по умолчанию
  TrafficCmd();
  // Конструктор команды
  TrafficCmd(unsigned char _first_led, unsigned char _second_led, unsigned char _third_led, unsigned char _fourth_led);
  // Перегрузка опреатора сравнения
  bool operator==(const TrafficCmd _right);
};

#endif //__TRAFFIC_CMD_H_
