#ifndef __TRAFFIC_H_
#define __TRAFFIC_H_

#include "TrafficCmd.h"
#include "DeviceBase.h"

// Класс светофора
class Traffic : public DeviceBase<TrafficCmd>
{

public:
      // Конструктор с номером
      Traffic(unsigned char _number);
      // Конструктор с номером и командами
      Traffic(unsigned char _number, std::vector<TrafficCmd> _commands);
};

#endif //__TRAFFIC_H_
