#include "Traffic.h"

// Конструктор
Traffic::Traffic(unsigned char _number) : DeviceBase(_number)
{
}

// Конструктор с указанными параметрами
Traffic::Traffic(unsigned char _number, std::vector<TrafficCmd> _commands)  : DeviceBase(_number, _commands)
{
}