#ifndef __DEPOT_MANAGER_H_
#define __DEPOT_MANAGER_H_

#include "Train.h"
#include "Arrow.h"
#include "Traffic.h"
// #include "DCC.h"

struct DepotManager
{
public:
  // Объект для работы с поездами
  // std::vector<Train> trains;
  // Объет для работы с устройствами DCC
  // DCC dcc;
  // Получить количество устройств
  // 0 - поездов
  // 1 - светофоров
  // 2 - стрелочных переводов
  // unsigned char GetCountDevices(unsigned char _device_type);
};

#endif //__DEPOT_MANAGER_H_
