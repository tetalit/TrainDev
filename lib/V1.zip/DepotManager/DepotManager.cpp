#include "DepotManager.h"

// Получить количество устройств
// 0 - поездов
// 1 - светофоров
// 2 - стрелочных переводов
// unsigned char DepotManager::GetCountDevices(unsigned char _device_type)
// {
//   if (_device_type == 0)
//   {
//     return trains.size();
//   }
//   else if (_device_type == 1)
//   {
//     return dcc.traffics.size();
//   }
//   else if (_device_type == 2)
//   {
//     return dcc.arrows.size();
//   }
//   Serial.println("Неверный тип устройства");
//   return 0;
// }