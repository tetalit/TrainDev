#pragma once
#ifndef __DEVICE_BASE_H_
#define __DEVICE_BASE_H_

#include "Definitions.h"

template <typename Cmd>
class DeviceBase
{
private:
  // Номер устройства
  unsigned char number;
  // Список команд для поезда
  std::vector<Cmd> commands;
  // Итератор команды
  unsigned short command_it;

protected:
  // Конструктор по умолчанию
  DeviceBase(){};
  // Конструктор с номером
  DeviceBase(unsigned char _number)
  {
    if (_number > 0 && _number < MAX_CMD_COUNT)
    {
      number = _number;
    }
  };
  // Конструктор с номером и командами
  DeviceBase(unsigned char _number, std::vector<Cmd> _commands)
  {
    if (_number > 0 && _number < MAX_CMD_COUNT)
    {
      number = _number;
      commands = _commands;
    }
  };

public:
  // Задать команду(итератор)
  bool SetCommandIterator(unsigned char _command_it)
  {
    // Если итератор лежит в допустимых пределах
    if (_command_it < commands.size() && _command_it > 0)
    {
      command_it = _command_it;
      return true;
    }
    return false;
  };

  // Добавить команду
  bool AddCmd(Cmd _cmd)
  {
    // Не выходим за рамки допустимого количества команд
    if (commands.size() < MAX_CMD_COUNT)
    {
      commands.push_back(_cmd);
      return true;
    }
    return false;
  };

  // Добавить команду на позицию
  bool AddCmdOnIndex(unsigned char _index, Cmd _cmd)
  {
    // Не выходим за рамки допустимого количества команд и индекс должен соответствовать допустимому
    if (commands.size() < MAX_CMD_COUNT && (_index < commands.size() && _index > 0))
    {
      auto iter = commands.begin();
      commands.insert(iter + _index, _cmd);
      return true;
    }
    return false;
  };

  // Удалить команду
  bool DeleteCmd(Cmd _cmd)
  {
    auto iter = commands.begin();
    for (auto cmd : commands)
    {
      if (cmd == _cmd)
      {
        commands.erase(iter);
        return true;
      }
      iter++;
    }
    return false;
  };

  // Удалить команду по индексу
  bool DeleteCmdOnIndex(unsigned char _index)
  {
    // Если итератор в допустимых диапазонах
    if (_index < commands.size() && _index > 0)
    {
      auto iter = commands.begin();
      commands.erase(iter + _index);
      return true;
    }
    return false;
  };

  // Получить текущую команду
  Cmd GetCurCmd()
  {
    return commands.at(command_it);
  };

  // Получить команду по индексу
  Cmd GetIndCmd(unsigned char _index)
  {
    // Если итератор в допустимых диапазонах
    if (_index < commands.size() && _index > 0)
    {
      return commands.at(_index);
    }
    return Cmd();
  };

  // Изменить команду по индексу
  bool ChangeCmd(unsigned char _index, Cmd _new_cmd)
  {
    // Если итератор в допустимых диапазонах
    if (_index < commands.size() && _index > 0)
    {
      commands.at(_index) = _new_cmd;
      return true;
    }
    return false;
  };

  // Получить номер устройства
  unsigned char GetNum()
  {
    return number;
  };

  // Проверка на наличие команд для устройства
  bool CommandsAvailable()
  {
    return (commands.size() > 0);
  };

  // Следующая команда
  void NextCommand()
  {
    Serial.printf("Размер вектора команд: %s\n", String(commands.size()));
    Serial.printf("Итератор: %s\n", String(command_it));
    if (command_it < commands.size() - 1)
      command_it++;
    else
      command_it = 0;
  };

  // Предыдущая команда
  void PrevCommand()
  {
    if (command_it > 0)
      command_it--;
    else
      command_it = commands.size() - 1;
  };

  // Выбрать текущую команду
  void SelectCommand(unsigned char _cmd_number)
  {
    if (_cmd_number >= 0 && _cmd_number <= commands.size())
    {
      command_it = _cmd_number;
    }
    else
    {
      Serial.println("Недопустимый номер команды");
    }
  };
};

#endif //__DEVICE_BASE_H_
