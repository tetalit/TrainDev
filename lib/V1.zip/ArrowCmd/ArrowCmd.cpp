#include "ArrowCmd.h"

// Конструктор по умолчанию
ArrowCmd::ArrowCmd()
{
   direction = RIGHT;
}

// Конструктор команды
ArrowCmd::ArrowCmd(unsigned char _direction)
{
   direction = _direction;
}

// Перегрузка опреатора сравнения
bool ArrowCmd::operator==(const ArrowCmd _right)
{
   return direction == _right.direction;
}