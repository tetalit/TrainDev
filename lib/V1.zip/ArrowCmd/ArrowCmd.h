#pragma once
#ifndef __ARROW_CMD_H_
#define __ARROW_CMD_H_

#include "Definitions.h"

struct ArrowCmd
{
public:
  // Направление стрелочного перевода
  unsigned char direction;
  // Конструктор по умолчанию
  ArrowCmd();
  // Конструктор команды
  ArrowCmd(unsigned char _direction);
  // Перегрузка опреатора сравнения
  bool operator==(const ArrowCmd _right);
};

#endif //__ARROW_CMD_H_
