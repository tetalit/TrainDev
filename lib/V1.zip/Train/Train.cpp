#include "Train.h"

// Конструктор
Train::Train(unsigned char _number) : DeviceBase(_number)
{
}

// Конструктор с указанными параметрами
Train::Train(unsigned char _number, std::vector<TrainCmd> _commands)  : DeviceBase(_number, _commands)
{
}