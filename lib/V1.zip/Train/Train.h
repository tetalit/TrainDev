#ifndef __TRAIN_H_
#define __TRAIN_H_

#include "TrainCmd.h"
#include "DeviceBase.h"

// Класс поезда
class Train : public DeviceBase<TrainCmd>
{

public:
      // Конструктор с номером
      Train(unsigned char _number);
      // Конструктор с номером и командами
      Train(unsigned char _number, std::vector<TrainCmd> _commands);
};

#endif //__TRAIN_H_
