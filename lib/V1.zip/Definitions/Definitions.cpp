//Включение заголовочного файла определений
#include "Definitions.h"

// Передаваемая команда
extern uint8_t command[CMD_COUNT] = { 0x00 };
// Длина передаваемой команды
extern uint8_t lengthCMD = 0x00;

// Расчет контрольной суммы
uint8_t Definitions::setCRC()
{
  // Если привышена длина сообщения,
  if (lengthCMD >= CMD_COUNT)
    return 0x00;
  // Рассчитываем контрольную сумму
  uint8_t i,
          crc = 0x00;
  for (i = 0x00; i < lengthCMD; i++)
    crc ^= command[i];
  // Сохраняем контрольную сумму. Изменяем длину пакета
  command[lengthCMD] = crc;
  ++lengthCMD;
  // Вернуть подтвержение расчета контрольной суммы
  return lengthCMD;
}

String Definitions::CommandToString()
{
  // Формируем ответное сообшение
  String answer = String(command[0x00], DEC);
  for (uint8_t i = 0x01; i < lengthCMD; i++)
    answer +=  " " + String(command[i], DEC);
  return answer;
}
