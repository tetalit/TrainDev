#ifndef __SWITCHERS_H
#define __SWITCHERS_H

#include "Definitions.h"

/*
    Класс для работы со светофорами  
*/ 
class Switchers : Definitions
{
    public:
    		// Установка значения стрелочного перевода 
    		void setSwitch(uint16_t number,  uint8_t route = RIGHT);
    		// Сформировать команду функции стрелочного перевода 
    		void createCMDSwitch();
    		// Проверить наличие исполняемых команд
    		uint8_t available();
	  private:
		uint16_t  
  			arraySwitches[STACK_COUNT],   // Стек стрелочных переводов
  			cursorSwitch = 0x00,          // Курсор на записываемый элемент стрелочного перевода 
        iteratorSwitch = 0x00;        // Указатель на считываемый элемент стрелочного перевода 
};

#endif
