#include "Switchers.h"

// Установка значения стрелочного перевода 
void Switchers::setSwitch(uint16_t number,  uint8_t route)
{
  	// Проверка номера светофора на максимльный
  	if ((number > 0x800) || (number == 0x00))
  		  return;
  	// Сохраняем номер стрелочного перевода 
  	arraySwitches[cursorSwitch] = number;
  	// Устанавливаем направление переключения
  	if (route)
  	    arraySwitches[cursorSwitch] |= 1UL << 0x0F;
  	// Изменение номера указателя 
  	if (++cursorSwitch >= STACK_COUNT)
  		  cursorSwitch = 0x00;   
}

//  Сформировать команду функции стрелочного перевода 
void Switchers::createCMDSwitch()
{
  	// Проверка есть ли доступные переводы
  	if (!available())
  		  return;
  	// Формирование команды перевода
  	// Сброс длины отправляемой команды
  	lengthCMD = 0x00;
  	// Установка адреса стрелочного перевода 
  	// Первый байт
  	command[lengthCMD] = (((arraySwitches[iteratorSwitch] - 0x01) & 0xFF) / 0x04 + 0x01) & 0x3F | 0x80;
    ++lengthCMD;    
  	// Второй байт
  	command[lengthCMD] = (((arraySwitches[iteratorSwitch] - 0x01) >> 0x08) ^ 0x0F) << 0x04 | 0x88;
  	// Направление переключения стрелочного перевода
  	if (arraySwitches[iteratorSwitch] >> 0x0F)
  		  command[lengthCMD] |= 0x01;   // Перевод влево, иначе вправо
  	// Добавление к адресу
  	command[lengthCMD] |= (arraySwitches[iteratorSwitch] - 0x01) % 0x04 << 0x01;
    ++lengthCMD;
  	// Рассчитываем контрольную сумму
  	lengthCMD = setCRC();
  	// Изменяем номер итератора
  	if (++iteratorSwitch >= STACK_COUNT)
  		  iteratorSwitch = 0x00; 
}

// Проверить наличие исполняемых команд
uint8_t Switchers::available()
{
	  return iteratorSwitch != cursorSwitch;
}
